const {HealthTrackerDB} = require('../db');
const cors = require('cors');

const express = require('express');
const app = express();
app.use(express.json());    
app.use(cors());

app.post('/addRecord',(req,res)=>{{
    const form=req.body;
    console.log("Form: ",form);
    HealthTrackerDB.create(form);
    res.status(200).json({"msg":"Record added successfully"});
}})

app.get('/getRecords',async(req,res)=>{
    const records=await HealthTrackerDB.find({});
    res.status(200).json(records);
})

app.delete('/deleteRecord',async(req,res)=>{
    const patientUID=req.body.patientUID;
    const result = await HealthTrackerDB.findByIdAndDelete(req.body.id);
    // const result = await HealthTrackerDB.findOneAndDelete({patientUID: patientUID});
    if (result) {
        res.status(200).json(result);
    } else {
    res.status(400).send("No document found with that ID.");
    }
});

app.listen(3000, () => {
    console.log("Server is running on port 3000");
});
