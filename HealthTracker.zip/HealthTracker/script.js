console.log("hi");
//db is for storing patient details 
let db=[];

function addRecord(){
    const form=document.getElementById('patientForm');
    if(form["patientName"].value==""||form["patientAge"].value==""||form["patientDescription"].value==""||form["patientUID"].value==""){
        alert("enter all details");
    }
    else{
        let temp={
            patientName:form["patientName"].value,
            patientAge:form["patientAge"].value,
            patientDescription:form["patientDescription"].value,
            patientUID:form["patientUID"].value,
            timeStamp:new Date().toISOString(),
            hash:"hash",
            previousHash:"previousHash"
        };

        // api to add data into DB
        fetch('http://localhost:3000/addRecord', {
            method:'POST',
            headers:{
                'Content-Type':'application/json'
            },
            body:JSON.stringify(temp)
        })
        .then(response => {
            return response.json();
        })
        .then(data => {
            console.log(data);
            alert("form submitted");
        })
        .catch(error => {
            console.error('Fetch error:', error.message);
        });
        // form.reset();
    }
}




async function populateAllRecords(){
    let allRecords = document.getElementById("allRecordsTableBody");
    allRecords.innerHTML="";
    //fetch method for getting data from DB
    let data = await fetch('http://localhost:3000/getRecords',{
        method:'GET'
    }).then(response=>{
        return response.json();
    }).then(data=>{
        console.log(data);
        return data;
    }).catch(err=>{
        console.log("Error Fetching Records: ",err);   
    })
    console.log("DB: ",data);

    for(let i=0;i<data.length;i++){
        //creating a new row
        const newRow = allRecords.insertRow();
            
        //creating cells
        const name = newRow.insertCell();
        const age = newRow.insertCell();
        const desc = newRow.insertCell();
        const uid = newRow.insertCell();
        const time = newRow.insertCell();
        const hash = newRow.insertCell();
        const prevHash = newRow.insertCell();

        //filling the cells with data
        name.textContent = data[i]["patientName"];
        age.textContent = data[i]["patientAge"];
        desc.textContent = data[i]["patientDescription"];
        uid.textContent = data[i]["patientUID"];
        time.textContent = data[i]["timeStamp"];
        hash.textContent = data[i]["hash"];
        prevHash.textContent = data[i]["previousHash"];
    }
}